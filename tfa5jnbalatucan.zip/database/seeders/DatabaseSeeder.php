<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('demo_records')->insert([
            ['record_type' => 'customer', 'record_code' => 'CUS-1001', 'record_name' => 'Maria Santos', 'created_at' => now(), 'updated_at' => now()],
            ['record_type' => 'customer', 'record_code' => 'CUS-1002', 'record_name' => 'Daniel Reyes', 'created_at' => now(), 'updated_at' => now()],
            ['record_type' => 'user', 'record_code' => 'USR-2001', 'record_name' => 'Admin User', 'created_at' => now(), 'updated_at' => now()],
            ['record_type' => 'user', 'record_code' => 'USR-2002', 'record_name' => 'Sofia Navarro', 'created_at' => now(), 'updated_at' => now()],
        ]);
    }
}
