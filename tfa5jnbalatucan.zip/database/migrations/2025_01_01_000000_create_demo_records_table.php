<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('demo_records', function (Blueprint $table) {
            $table->id();
            $table->string('record_type');
            $table->string('record_code')->unique();
            $table->string('record_name');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('demo_records');
    }
};
