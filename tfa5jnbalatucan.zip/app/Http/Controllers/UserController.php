<?php

namespace App\Http\Controllers;

use Illuminate\View\View;

class UserController extends Controller
{
    public function index(): View
    {
        $users = [
            ['id' => 'USR-2001', 'name' => 'Admin User', 'email' => 'admin@pos.test', 'role' => 'Administrator', 'status' => 'Active'],
            ['id' => 'USR-2002', 'name' => 'Sofia Navarro', 'email' => 'sofia.navarro@pos.test', 'role' => 'Cashier', 'status' => 'Active'],
            ['id' => 'USR-2003', 'name' => 'Miguel Torres', 'email' => 'miguel.torres@pos.test', 'role' => 'Inventory Clerk', 'status' => 'Active'],
            ['id' => 'USR-2004', 'name' => 'Carla Flores', 'email' => 'carla.flores@pos.test', 'role' => 'Cashier', 'status' => 'Inactive'],
            ['id' => 'USR-2005', 'name' => 'Ramon Aquino', 'email' => 'ramon.aquino@pos.test', 'role' => 'Supervisor', 'status' => 'Active'],
        ];

        return view('users', compact('users'));
    }
}
