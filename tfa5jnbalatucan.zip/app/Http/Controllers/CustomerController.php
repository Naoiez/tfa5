<?php

namespace App\Http\Controllers;

use Illuminate\View\View;

class CustomerController extends Controller
{
    public function index(): View
    {
        $customers = [
            ['id' => 'CUS-1001', 'name' => 'Maria Santos', 'email' => 'maria.santos@example.com', 'status' => 'Active', 'joined' => '2025-01-12'],
            ['id' => 'CUS-1002', 'name' => 'Daniel Reyes', 'email' => 'daniel.reyes@example.com', 'status' => 'Active', 'joined' => '2025-02-08'],
            ['id' => 'CUS-1003', 'name' => 'Angela Cruz', 'email' => 'angela.cruz@example.com', 'status' => 'Pending', 'joined' => '2025-03-17'],
            ['id' => 'CUS-1004', 'name' => 'Joshua Garcia', 'email' => 'joshua.garcia@example.com', 'status' => 'Active', 'joined' => '2025-04-25'],
            ['id' => 'CUS-1005', 'name' => 'Leah Mendoza', 'email' => 'leah.mendoza@example.com', 'status' => 'Inactive', 'joined' => '2025-05-03'],
        ];

        return view('customers', compact('customers'));
    }
}
