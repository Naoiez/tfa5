# Laravel POS Foundations

This project is the completed IT0049 TFA5 activity, **From Zero to Four Pages, Again: Your First Laravel Application**.

## Included requirements

- `/` landing page
- `/about` About page
- `/customers` Customer Accounts page with five static records
- `/users` User Accounts page with five static records
- `PageController`, `CustomerController`, and `UserController`
- Blade layouts and views with `@foreach` loops
- Navigation links between every page
- SQLite migration and seeder files for the submission requirement
- InfinityFree-friendly `public/index.php` fallback when `vendor/` is not available

## Local Laravel setup

1. Install PHP 8.2+, Composer, and Laravel's required PHP extensions.
2. Copy `.env.example` to `.env`.
3. Run `composer install`.
4. Run `php artisan key:generate`.
5. Create the SQLite file at `database/database.sqlite`.
6. Run `php artisan migrate --seed`.
7. Start the application with `php artisan serve`.
8. Open `http://127.0.0.1:8000`.

## InfinityFree deployment

Upload the contents of this folder to `htdocs`. The root entry point detects a normal Laravel `vendor/autoload.php` installation when present. If InfinityFree does not provide Composer dependencies, it automatically serves the same four required pages using the included controllers' data and Blade-compatible templates. Set `APP_URL` in `.env` to your live domain when using a full Laravel installation.

For a full Laravel deployment, run `composer install --no-dev` locally and upload the generated `vendor` folder as well. Point the domain document root to `public` if your hosting plan permits it; otherwise upload the contents of `public` into `htdocs` and keep the application folders one level above it.
