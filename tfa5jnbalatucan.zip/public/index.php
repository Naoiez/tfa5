<?php

// Normal Laravel entry point when Composer dependencies are installed.
$autoload = dirname(__DIR__) . '/vendor/autoload.php';
if (is_file($autoload)) {
    require $autoload;
    $app = require_once dirname(__DIR__) . '/bootstrap/app.php';
    $app->handleRequest(\Illuminate\Http\Request::capture());
    exit;
}

// Hosting fallback: keeps the submitted four-page activity usable on basic PHP hosting
// when Composer/vendor files cannot be uploaded. The Laravel source remains in the project.
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = rtrim($path, '/') ?: '/';
$base = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/');
if ($base !== '' && $base !== '/') {
    $path = preg_replace('#^' . preg_quote($base, '#') . '#', '', $path) ?: '/';
}

$customers = [
    ['id' => 'CUS-1001', 'name' => 'Maria Santos', 'email' => 'maria.santos@example.com', 'status' => 'Active', 'joined' => '2025-01-12'],
    ['id' => 'CUS-1002', 'name' => 'Daniel Reyes', 'email' => 'daniel.reyes@example.com', 'status' => 'Active', 'joined' => '2025-02-08'],
    ['id' => 'CUS-1003', 'name' => 'Angela Cruz', 'email' => 'angela.cruz@example.com', 'status' => 'Pending', 'joined' => '2025-03-17'],
    ['id' => 'CUS-1004', 'name' => 'Joshua Garcia', 'email' => 'joshua.garcia@example.com', 'status' => 'Active', 'joined' => '2025-04-25'],
    ['id' => 'CUS-1005', 'name' => 'Leah Mendoza', 'email' => 'leah.mendoza@example.com', 'status' => 'Inactive', 'joined' => '2025-05-03'],
];
$users = [
    ['id' => 'USR-2001', 'name' => 'Admin User', 'email' => 'admin@pos.test', 'role' => 'Administrator', 'status' => 'Active'],
    ['id' => 'USR-2002', 'name' => 'Sofia Navarro', 'email' => 'sofia.navarro@pos.test', 'role' => 'Cashier', 'status' => 'Active'],
    ['id' => 'USR-2003', 'name' => 'Miguel Torres', 'email' => 'miguel.torres@pos.test', 'role' => 'Inventory Clerk', 'status' => 'Active'],
    ['id' => 'USR-2004', 'name' => 'Carla Flores', 'email' => 'carla.flores@pos.test', 'role' => 'Cashier', 'status' => 'Inactive'],
    ['id' => 'USR-2005', 'name' => 'Ramon Aquino', 'email' => 'ramon.aquino@pos.test', 'role' => 'Supervisor', 'status' => 'Active'],
];
$esc = static fn ($value) => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$url = static fn ($route) => ($base ?: '') . $route;
$title = $path === '/about' ? 'About' : ($path === '/customers' ? 'Customers' : ($path === '/users' ? 'Users' : 'Home'));
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= $esc($title) ?> | POS Foundations</title><style>:root{--navy:#102a43;--blue:#2471a3;--sky:#eaf4fb;--ink:#243b53;--muted:#627d98;--line:#d9e2ec}*{box-sizing:border-box}body{margin:0;color:var(--ink);background:#f7fafc;font-family:Arial,Helvetica,sans-serif;line-height:1.5}.nav{background:var(--navy);color:#fff}.nav-inner{max-width:1080px;margin:auto;display:flex;align-items:center;justify-content:space-between;padding:18px 24px;gap:24px}.brand,.nav a{color:#fff;text-decoration:none}.nav-links{display:flex;gap:8px;flex-wrap:wrap}.nav-links a{color:#d9eaf7;padding:8px 12px;border-radius:6px;font-size:14px}.container{max-width:1080px;margin:auto;padding:48px 24px 64px}.eyebrow{color:var(--blue);text-transform:uppercase;letter-spacing:1.5px;font-size:12px;font-weight:700;margin:0 0 10px}h1{color:var(--navy);margin:0 0 14px;font-size:clamp(30px,5vw,48px);line-height:1.1}h2{color:var(--navy)}p{color:var(--muted)}.lead{font-size:18px;max-width:720px}.hero{background:linear-gradient(135deg,#eaf4fb,#fff);border:1px solid var(--line);border-radius:14px;padding:42px}.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:26px}.button{display:inline-block;background:var(--blue);color:#fff;text-decoration:none;font-weight:700;padding:11px 16px;border-radius:7px}.secondary{background:#fff;color:var(--blue);border:1px solid #9fbad0}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-top:28px}.card{background:#fff;border:1px solid var(--line);border-radius:10px;padding:22px}.card h3{margin:0 0 8px;color:var(--navy)}.page-header{display:flex;justify-content:space-between;align-items:end;gap:20px;margin-bottom:24px}.table-wrap{overflow-x:auto;background:#fff;border:1px solid var(--line);border-radius:10px}table{width:100%;border-collapse:collapse;min-width:680px}th,td{text-align:left;padding:15px 18px;border-bottom:1px solid var(--line);font-size:14px}th{background:var(--sky);color:var(--navy);font-size:12px;text-transform:uppercase;letter-spacing:.6px}.badge{display:inline-block;border-radius:999px;padding:4px 10px;font-size:12px;font-weight:700;background:#e6f4ea;color:#26733a}.pending{background:#fff4d6;color:#8a5b00}.inactive{background:#f1f3f5;color:#6b7280}.footer{border-top:1px solid var(--line);color:var(--muted);font-size:13px;padding:22px 24px;text-align:center}@media(max-width:700px){.nav-inner,.page-header{align-items:flex-start;flex-direction:column}.hero{padding:28px 22px}.cards{grid-template-columns:1fr}}</style></head><body><nav class="nav"><div class="nav-inner"><a class="brand" href="<?= $url('/') ?>">POS Foundations</a><div class="nav-links"><a href="<?= $url('/') ?>">Home</a><a href="<?= $url('/about') ?>">About</a><a href="<?= $url('/customers') ?>">Customers</a><a href="<?= $url('/users') ?>">Users</a></div></div></nav><main class="container">
<?php if ($path === '/customers' || $path === '/users'): $records = $path === '/customers' ? $customers : $users; ?><div class="page-header"><div><p class="eyebrow">Account management</p><h1><?= $path === '/customers' ? 'Customer Accounts' : 'User Accounts' ?></h1><p>Sample records from a static PHP array.</p></div><a class="button" href="<?= $url($path === '/customers' ? '/users' : '/customers') ?>">View <?= $path === '/customers' ? 'users' : 'customers' ?></a></div><div class="table-wrap"><table><thead><tr><?php foreach (array_keys($records[0]) as $heading): ?><th><?= $esc(ucfirst($heading)) ?></th><?php endforeach; ?></tr></thead><tbody><?php foreach ($records as $record): ?><tr><?php foreach ($record as $key => $value): ?><td><?php if ($key === 'status'): ?><span class="badge <?= strtolower($esc($value)) ?>"><?= $esc($value) ?></span><?php else: ?><?= $esc($value) ?><?php endif; ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody></table></div>
<?php elseif ($path === '/about'): ?><p class="eyebrow">About this project</p><h1>Built around Laravel MVC</h1><p class="lead">This activity demonstrates how a request moves through a Laravel application: a route calls a controller method, the controller prepares data, and a Blade view renders the response.</p><section class="cards"><article class="card"><h3>Routes</h3><p>All four pages are registered in <code>routes/web.php</code>.</p></article><article class="card"><h3>Controllers</h3><p>PageController handles static pages, while CustomerController and UserController handle account lists.</p></article><article class="card"><h3>Temporary data</h3><p>Each account page uses a static PHP array with five sample records.</p></article></section>
<?php else: ?><section class="hero"><p class="eyebrow">Laravel POS Foundations</p><h1>Simple records. Clear operations.</h1><p class="lead">A four-page point-of-sale foundation built with Laravel's MVC architecture, controller methods, routes, and Blade templates.</p><div class="actions"><a class="button" href="<?= $url('/customers') ?>">View customers</a><a class="button secondary" href="<?= $url('/about') ?>">Learn about the app</a></div></section><section class="cards"><article class="card"><h3>Customers</h3><p>Review customer account records.</p></article><article class="card"><h3>Users</h3><p>Review account users and roles.</p></article><article class="card"><h3>Blade views</h3><p>Account rows are rendered in loops.</p></article></section><?php endif; ?></main><footer class="footer">IT0049 Web System Technologies &middot; Laravel Foundations</footer></body></html>
