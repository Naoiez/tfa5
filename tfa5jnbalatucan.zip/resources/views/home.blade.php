@extends('layouts.app', ['title' => 'Home'])
@section('content')
<section class="hero">
    <p class="eyebrow">Laravel POS Foundations</p>
    <h1>Simple records. Clear operations.</h1>
    <p class="lead">A four-page point-of-sale foundation built with Laravel's MVC architecture, controller methods, routes, and Blade templates.</p>
    <div class="actions"><a class="button" href="{{ url('/customers') }}">View customers</a><a class="button secondary" href="{{ url('/about') }}">Learn about the app</a></div>
</section>
<section class="cards"><article class="card"><h3>Customers</h3><p>Review customer account records prepared by the CustomerController.</p></article><article class="card"><h3>Users</h3><p>Review account users and their assigned roles from the UserController.</p></article><article class="card"><h3>Blade views</h3><p>All account rows are rendered through a Blade <code>@foreach</code> loop.</p></article></section>
@endsection
