@extends('layouts.app', ['title' => 'About'])
@section('content')
<p class="eyebrow">About this project</p><h1>Built around Laravel MVC</h1><p class="lead">This activity demonstrates how a request moves through a Laravel application: a route calls a controller method, the controller prepares data, and a Blade view renders the response.</p>
<section class="cards"><article class="card"><h3>Routes</h3><p>All four pages are registered in <code>routes/web.php</code>.</p></article><article class="card"><h3>Controllers</h3><p>PageController handles static pages, while CustomerController and UserController handle account lists.</p></article><article class="card"><h3>Temporary data</h3><p>Each account page uses a static PHP array with five sample records.</p></article></section>
@endsection
