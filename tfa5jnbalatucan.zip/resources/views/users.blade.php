@extends('layouts.app', ['title' => 'Users'])
@section('content')
<div class="page-header"><div><p class="eyebrow">System access</p><h1>User Accounts</h1><p>Sample user records from a static PHP array.</p></div><a class="button" href="{{ url('/customers') }}">View customers</a></div>
<div class="table-wrap"><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th></tr></thead><tbody>@foreach ($users as $user)<tr><td>{{ $user['id'] }}</td><td>{{ $user['name'] }}</td><td>{{ $user['email'] }}</td><td>{{ $user['role'] }}</td><td><span class="badge {{ strtolower($user['status']) }}">{{ $user['status'] }}</span></td></tr>@endforeach</tbody></table></div>
@endsection
