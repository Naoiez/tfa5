@extends('layouts.app', ['title' => 'Customers'])
@section('content')
<div class="page-header"><div><p class="eyebrow">Account management</p><h1>Customer Accounts</h1><p>Sample customer records from a static PHP array.</p></div><a class="button" href="{{ url('/users') }}">View users</a></div>
<div class="table-wrap"><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Status</th><th>Joined</th></tr></thead><tbody>@foreach ($customers as $customer)<tr><td>{{ $customer['id'] }}</td><td>{{ $customer['name'] }}</td><td>{{ $customer['email'] }}</td><td><span class="badge {{ strtolower($customer['status']) }}">{{ $customer['status'] }}</span></td><td>{{ $customer['joined'] }}</td></tr>@endforeach</tbody></table></div>
@endsection
