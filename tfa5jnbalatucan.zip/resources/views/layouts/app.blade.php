<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'POS Foundations' }} | POS Foundations</title>
    <style>
        :root { --navy:#102a43; --blue:#2471a3; --sky:#eaf4fb; --ink:#243b53; --muted:#627d98; --line:#d9e2ec; --white:#fff; }
        * { box-sizing:border-box; } body { margin:0; color:var(--ink); background:#f7fafc; font-family:Arial,Helvetica,sans-serif; line-height:1.5; }
        .nav { background:var(--navy); color:white; } .nav-inner { max-width:1080px; margin:auto; display:flex; align-items:center; justify-content:space-between; padding:18px 24px; gap:24px; }
        .brand { color:#fff; text-decoration:none; font-weight:700; letter-spacing:.3px; } .nav-links { display:flex; gap:8px; flex-wrap:wrap; } .nav-links a { color:#d9eaf7; text-decoration:none; padding:8px 12px; border-radius:6px; font-size:14px; } .nav-links a:hover { background:#1d4e73; color:#fff; }
        .container { max-width:1080px; margin:0 auto; padding:48px 24px 64px; } .eyebrow { color:var(--blue); text-transform:uppercase; letter-spacing:1.5px; font-size:12px; font-weight:700; margin:0 0 10px; } h1 { color:var(--navy); margin:0 0 14px; font-size:clamp(30px,5vw,48px); line-height:1.1; } h2 { color:var(--navy); margin-top:0; } p { color:var(--muted); } .lead { font-size:18px; max-width:720px; }
        .hero { background:linear-gradient(135deg,#eaf4fb,#fff); border:1px solid var(--line); border-radius:14px; padding:42px; } .actions { display:flex; gap:12px; flex-wrap:wrap; margin-top:26px; } .button { display:inline-block; background:var(--blue); color:white; text-decoration:none; font-weight:700; padding:11px 16px; border-radius:7px; } .button.secondary { background:white; color:var(--blue); border:1px solid #9fbad0; }
        .cards { display:grid; grid-template-columns:repeat(3,1fr); gap:18px; margin-top:28px; } .card { background:white; border:1px solid var(--line); border-radius:10px; padding:22px; } .card h3 { margin:0 0 8px; color:var(--navy); } .card p { margin:0; font-size:14px; }
        .page-header { display:flex; justify-content:space-between; align-items:end; gap:20px; margin-bottom:24px; } .page-header p { margin:0; } .table-wrap { overflow-x:auto; background:white; border:1px solid var(--line); border-radius:10px; } table { width:100%; border-collapse:collapse; min-width:680px; } th,td { text-align:left; padding:15px 18px; border-bottom:1px solid var(--line); font-size:14px; } th { background:var(--sky); color:var(--navy); font-size:12px; text-transform:uppercase; letter-spacing:.6px; } tr:last-child td { border-bottom:0; } .badge { display:inline-block; border-radius:999px; padding:4px 10px; font-size:12px; font-weight:700; background:#e6f4ea; color:#26733a; } .badge.pending { background:#fff4d6; color:#8a5b00; } .badge.inactive { background:#f1f3f5; color:#6b7280; }
        .footer { border-top:1px solid var(--line); color:var(--muted); font-size:13px; padding:22px 24px; text-align:center; } @media (max-width:700px) { .nav-inner,.page-header { align-items:flex-start; flex-direction:column; } .hero { padding:28px 22px; } .cards { grid-template-columns:1fr; } }
    </style>
</head>
<body>
<nav class="nav"><div class="nav-inner"><a class="brand" href="{{ url('/') }}">POS Foundations</a><div class="nav-links"><a href="{{ url('/') }}">Home</a><a href="{{ url('/about') }}">About</a><a href="{{ url('/customers') }}">Customers</a><a href="{{ url('/users') }}">Users</a></div></div></nav>
<main class="container">@yield('content')</main>
<footer class="footer">IT0049 Web System Technologies &middot; Laravel Foundations</footer>
</body>
</html>
